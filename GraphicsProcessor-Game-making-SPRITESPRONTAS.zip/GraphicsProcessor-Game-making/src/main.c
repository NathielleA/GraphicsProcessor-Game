#include <errno.h>
#include <fcntl.h>
#include <linux/input.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>

#include "GraphSync.h"

//-------------------------------------------------------------

int main(void) {
  set_game_sprites();

  set_background_color(4, 5, 1);

  clean_background();
  clean_sprite();

  // sprite_fixed_t sprite;
  // sprite.ativo = 1;
  // sprite.coord_x = 200;
  // sprite.coord_y = 200;
  // sprite.data_register = 3;
  // sprite.offset = 1;

  // u16_t i;
  // for (i = 0; i < 19; i++) {
  //   sprite.offset = i;
  //   set_fixed_sprite(sprite);
  //   sleep(2);
  // }

  return 0;
}
