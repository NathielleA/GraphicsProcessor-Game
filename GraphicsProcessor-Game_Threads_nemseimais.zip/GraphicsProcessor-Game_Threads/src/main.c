#include <errno.h>
#include <fcntl.h>
#include <linux/input.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>

#include "GameVisualization.h"
#include "GraphSync.h"

#define KEY_BASE 0X0
#define LW_BRIDGE_SPAN 0x00005000
#define LW_BRIDGE_BASE 0xff200000

#define MOUSE_DEVICE_PATH "/dev/input/mice"

#define START 0
#define GAME 1
#define PAUSE 2
#define RESTART 3

volatile i8_t state_game;
pthread_mutex_t mutex;

void change_state(volatile i32_t* KEY_ptr, volatile i8_t edge_capture) {
  switch (state_game) {
    case START:
      if (*KEY_ptr == 0b0111 && edge_capture) {  // primeiro botão da placa, tecla pressionada
        state_game = GAME;
      } else if (*KEY_ptr == 0b1111) {
        state_game = START;
      }
      break;

    case GAME:
      if (*KEY_ptr == 0b0111 && edge_capture) {  // primeiro botão da placa, tecla pressionada
        state_game = PAUSE;
      } else if (*KEY_ptr == 0b1111) {
        state_game = GAME;
      }
      break;

    case PAUSE:
      if (*KEY_ptr == 0b0111 && edge_capture) {  // primeiro botão da placa, tecla pressionada
        state_game = GAME;
      } else if (*KEY_ptr == 0b1011 && edge_capture) {  // segundo botão da placa, tecla pressionada
        state_game = RESTART;
      } else if (*KEY_ptr == 0b1101 && edge_capture) {  // terceiro botão da placa, tecla pressionada
        state_game = START;
      } else if (*KEY_ptr == 0b1111) {
        state_game = PAUSE;
      }
      break;

    case RESTART:
      state_game = GAME;  // terceiro botão da placa, tecla pressionada
      system("clear");

      break;

    default:
      break;
  }
}

void* key_thread(void* args) {
  volatile i8_t* state_game = (volatile i8_t*)args;

  static i32_t fd_map = -1;

  fd_map = open("/dev/mem", (O_RDWR | O_SYNC));
  if (fd_map == -1) {
    perror("Error maping memory");
    exit(EXIT_FAILURE);
  }

  void* LW_virtual = mmap(NULL, LW_BRIDGE_SPAN, (PROT_READ | PROT_WRITE), MAP_SHARED, fd_map, LW_BRIDGE_BASE);
  if (LW_virtual == MAP_FAILED) {
    perror("Error maping memory");
    exit(EXIT_FAILURE);
  }

  volatile i32_t* KEY_ptr = (i32_t*)(LW_virtual + KEY_BASE);
  i8_t edge_capture = 1;
  i32_t previous_key_state = 0b1111;
  i32_t current_key_state;
  ;

  while (1) {
    current_key_state = *KEY_ptr;
    if (previous_key_state == current_key_state) {
      edge_capture = 0;
    } else {
      edge_capture = 1;
    }

    previous_key_state = current_key_state;

    change_state(KEY_ptr, edge_capture);
  }

  if (munmap(LW_virtual, LW_BRIDGE_SPAN) == -1) {
    perror("Error ending ");
    exit(EXIT_FAILURE);
  }
  if (close(fd_map) == -1) {
    perror("Error ending device");
    exit(EXIT_FAILURE);
  }

  pthread_exit(args);
}

// // void* mouse_thread() {
// //   static i64_t fd_mouse = -1;

// //   fd_mouse = open(MOUSE_DEVICE_PATH, O_RDONLY);
// //   if (fd_mouse == -1) {
// //     perror("Error opening device");
// //     exit(EXIT_FAILURE);
// //   }

// //   struct input_event ev_mouse;

// //   sprite_t frog;
// //   frog.ativo = 1;
// //   frog.coord_x = 320;
// //   frog.coord_y = 450;
// //   frog.data_register = 30;
// //   frog.speed = 1;
// //   frog.offset = 1;

// //   u16_t i;
// //   printf("Chegou 1");

// //   while (1) {
// //     ssize_t mouse_read = read(fd_mouse, &ev_mouse, sizeof(ev_mouse));

// //     if (mouse_read == (ssize_t)-1) {
// //       perror("Error reading mouse event");
// //       close(fd_mouse);
// //       exit(EXIT_FAILURE);
// //     }

// //     if (ev_mouse.code == REL_X) {
// //       frog.coord_x += ev_mouse.value;
// //       printf("Chegou 2 \n");
// //     } else if (ev_mouse.type == EV_KEY) {
// //       if (ev_mouse.code == BTN_LEFT) {
// //         frog.coord_y -= 10;
// //       } else if (ev_mouse.code == BTN_RIGHT) {
// //         frog.coord_y += 10;
// //       }
// //     }

// //     // printf("Chegou\n");
// //     set_dynamic_sprite(frog);

// //     if (ev_mouse.code == REL_X) {
// //       // printf("Movimento horizontal: %d\n", ev_mouse.value);
// //     }
// //   }

// //   if (close(fd_mouse) == -1) {
// //     perror("Error ending device");
// //     exit(EXIT_FAILURE);
// //   }
// //   pthread_exit(NULL);
// // }

void* mouse_thread(void* arg) {
  sprite_t* cursor = (sprite_t*)arg;
  static i64_t fd_mouse = -1;

  fd_mouse = open(MOUSE_DEVICE_PATH, O_RDONLY);
  if (fd_mouse == -1) {
    perror("Error opening device");
    exit(EXIT_FAILURE);
  }

  struct input_event ev_mouse;

  // Abrindo o dispositivo do mouse (adapte o caminho conforme necessário)
  fd_mouse = open("/dev/input/event0", O_RDONLY);
  if (fd_mouse == -1) {
    perror("Erro ao abrir o dispositivo de entrada");
    exit(EXIT_FAILURE);
  }

  while (1) {
    ssize_t bytes = read(fd_mouse, &ev_mouse, sizeof(ev_mouse));
    if (bytes < sizeof(struct input_event)) {
      perror("Erro ao ler evento do mouse");
      exit(EXIT_FAILURE);
    }

    // Atualiza a posição do cursor baseado no movimento do mouse
    if (state_game == GAME && ev_mouse.type == EV_REL && ev_mouse.code == REL_X) {
      cursor->coord_x += ev_mouse.value;
    } else if (ev_mouse.type == EV_REL && ev_mouse.code == REL_Y) {
      // if (ev_mouse.code == BTN_LEFT) {
      //   cursor->coord_y -= 10;
      // } else if (ev_mouse.code == BTN_RIGHT) {
      //   cursor->coord_y += 10;
      // }
    }
  }

  pthread_exit(arg);
}
void* visul_thread() {
  // game_screen();
  // moving_sprites();
  pthread_exit(NULL);
}

int main(void) {
  set_game_sprites();

  state_game = 0;

  pthread_mutex_init(&mutex, NULL);

  sprite_t cursor;
  cursor.ativo = 1;
  cursor.data_register = 1;
  cursor.offset = 1;
  cursor.coord_x = 320;
  cursor.coord_y = 450;
  cursor.collision = 0;

  pthread_t thread_key_id;
  pthread_t thread_mouse_id;
  pthread_t thread_visu_id;

  if (pthread_create(&thread_key_id, NULL, key_thread, (void*)&state_game) != 0) {
    perror("Error creating thread");
    return 1;
  }

  if (pthread_create(&thread_mouse_id, NULL, mouse_thread, (void*)&cursor) != 0) {
    perror("Error creating thread");
    return 1;
  }

  // if (pthread_create(&thread_visu_id, NULL, visul_thread, NULL) != 0) {
  //   perror("Error creating thread");
  //   return 1;
  // }

  clean_sprite();
  clean_polygon();

  while (1) {
    set_dynamic_sprite(cursor);
    switch (state_game) {
      case START:
        set_background_color(2, 3, 4);
        break;
      case GAME:
        set_background_color(7, 7, 7);
        set_dynamic_sprite(cursor);
        break;
      case PAUSE:
        set_background_color(0, 7, 0);
        break;
      case RESTART:
        set_background_color(0, 0, 7);
        break;
      default:
        break;
    }
  }
}

// void set_background_block_blocked(ground_block_t block) {
//   pthread_mutex_lock(&mutex);
//   set_background_block(block);
//   pthread_mutex_unlock(&mutex);
//   return;
// }

// void set_fixed_sprite_blocked(sprite_fixed_t sprite) {
//   pthread_mutex_lock(&mutex);
//   set_fixed_sprite(sprite);
//   pthread_mutex_unlock(&mutex);
//   return;
// }

// void set_dynamic_sprite_blocked(sprite_t sprite) {
//   pthread_mutex_lock(&mutex);
//   set_dynamic_sprite(sprite);
//   pthread_mutex_unlock(&mutex);
//   return;
// }

// void set_background_color_blocked(u32_t R, u32_t G, u32_t B) {
//   pthread_mutex_lock(&mutex);
//   set_background_color(R, G, B);
//   pthread_mutex_unlock(&mutex);
//   return;
// }

// void set_polygon_blocked(polygon_t polygon) {
//   pthread_mutex_lock(&mutex);
//   set_polygon(polygon);
//   pthread_mutex_unlock(&mutex);
//   return;
// }

// void increase_coordinate_sprite_blocked(sprite_t sprite, u32_t counter) {
//   pthread_mutex_lock(&mutex);
//   increase_coordinate_sprite(&sprite, counter);
//   pthread_mutex_unlock(&mutex);
//   return;
// }

// void clean_sprite_blocked() {
//   pthread_mutex_lock(&mutex);
//   clean_sprite();
//   pthread_mutex_unlock(&mutex);
//   return;
// }

// void clean_polygon_blocked() {
//   pthread_mutex_lock(&mutex);
//   clean_polygon();
//   pthread_mutex_unlock(&mutex);
//   return;
// }

// void clean_background_blocked() {
//   pthread_mutex_lock(&mutex);
//   clean_background();
//   pthread_mutex_unlock(&mutex);
//   return;
// }

