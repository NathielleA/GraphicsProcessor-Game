#include <stdio.h>

#include "utils/types.h"

void game_screen();

void moving_sprites();