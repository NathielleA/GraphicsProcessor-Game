#include <stdio.h>

#include "utils/types.h"

void set_new_sprite(u8_t sprite_name, u8_t sprite_offset);

u8_t select_sprite(u8_t sprite_name);